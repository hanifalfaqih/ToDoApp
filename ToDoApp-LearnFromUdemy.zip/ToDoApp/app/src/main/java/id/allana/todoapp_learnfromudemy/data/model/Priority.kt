package id.allana.todoapp_learnfromudemy.data.model

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}